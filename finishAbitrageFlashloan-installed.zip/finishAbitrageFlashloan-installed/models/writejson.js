const fs = require('fs');

// get ABI of an verified contract

const writeJson = async (jsonname, block, swapAmountOhneWei, uniswapV2V2BuyPrice, sushiswapV2BuyPrice, bakeryswapV2BuyPrice, apeswapV2BuyPrice, sushiswapV2SellPrice,  uniswapV2SellPrice,  bakerywapV2SellPrice, apeswapV2SellPrice) => {
  const path = jsonname;

  if (fs.existsSync(path)) {
    // path exists
    console.log("exists:", path);
    fs.readFile(path, 'utf8', function (err, data){
      if (err){
          console.log(err);
      } else {
      obj = JSON.parse(data); //now it an object
      obj.table.push({block: block.number, timestamp: block.timestamp, swapAmountBNB: swapAmountOhneWei, uniswapv2buyprice: uniswapV2V2BuyPrice, sushiswapv2buyprice: sushiswapV2BuyPrice, bakeryswapbuyprice: bakeryswapV2BuyPrice, apeswapBuyPrice: apeswapV2BuyPrice, uniswapv2sellprice: uniswapV2SellPrice, sushiswapv2sellprice: sushiswapV2SellPrice, bakeryswapsellprice: bakerywapV2SellPrice, apeswapsellprice: apeswapV2SellPrice});
      json = JSON.stringify(obj); //convert it back to json
      fs.writeFile(path, json, 'utf8', function (err) {
        if (err) {
            console.log("An error occured while writing JSON Object to File.");
            return console.log(err);
        }
      
        console.log("JSON file has been saved.");
      });
    }});

  } else {

    var obj = {
      table: []
   };

   obj.table.push({block: block.number, timestamp: block.timestamp, swapAmountBNB: swapAmountOhneWei, uniswapv2buyprice: uniswapV2V2BuyPrice, sushiswapv2buyprice: sushiswapV2BuyPrice, bakeryswapbuyprice: bakeryswapV2BuyPrice, apeswapBuyPrice: apeswapV2BuyPrice, uniswapv2sellprice: uniswapV2SellPrice, sushiswapv2sellprice: sushiswapV2SellPrice, bakeryswapsellprice: bakerywapV2SellPrice, apeswapsellprice: apeswapV2SellPrice});
   var json = JSON.stringify(obj);
  
   fs.writeFile(path, json, 'utf8', function (err) {
    if (err) {
        console.log("An error occured while writing JSON Object to File.");
        return console.log(err);
    }
  
    console.log("JSON file has been saved.");
  });
    console.log("DOES NOT exist:", path);

  }






  
};

module.exports = {
  writeJson,
};
