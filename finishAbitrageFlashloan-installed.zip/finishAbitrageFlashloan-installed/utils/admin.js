// configuration files
const config = require('../config');
const key = require('../helpers/key.js');


const HDWalletProvider = require('@truffle/hdwallet-provider');
const CryptoJS = require("crypto-js");

const fs = require('fs');


// node api
const Web3 = require('web3');

// connecting to node
const web3 = new Web3(config.wssEndpoint);
const web3Provider = new Web3(config.wssEndpoint);



var bytes  = CryptoJS.AES.decrypt(config.mnemonic , key);
var mnemonic= bytes.toString(CryptoJS.enc.Utf8);

let provider = new HDWalletProvider({
  mnemonic: mnemonic,
  providerOrUrl: config.wssEndpoint,
});

web3Provider.setProvider(provider);

module.exports = {
  web3,
  web3Provider,
}