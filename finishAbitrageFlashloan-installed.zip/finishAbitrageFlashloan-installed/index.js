// node connection
const BigNumber = require('bignumber.js');
const { web3, web3Provider } = require('./utils/admin');
const writeJson = require('./models/writeJson.js');
const swapAmountOhneWei = require('./helpers/swapAmount.js');

// configuration files
const { tokens, routers, ABIs, factories } = require('./addresses/ethereum');
const { ABI } = require('./addresses/ArbitrageAbi.js');
const config = require('./config');

// utils
const logger = require('./utils/logger');

// models
const EthereumCalculator = require('./models/EthereumCalculator');
const DexPriceAddress = require('./models/DexPriceAddress');
const { Console } = require('winston/lib/winston/transports');



const main = async () => {
  // user input of 2 tokens

  const swapFrom = 'WETH'; // Enter token name (3-4 letters)
  const swapTo = 'DAI';
  const swapAmount = BigNumber((swapAmountOhneWei) * 1e+18); // in wei

  
  const addresses = await web3Provider.eth.getAccounts();
 
  var contract = new web3Provider.eth.Contract(ABI.abi, "0x401da40Da97f8F7F5739F7bA67d81e9FED776293");

  //const data = await contract.methods.returnCurrentBalanceBNB().call();
/*
  try {
    await contract.methods.startArbitrage(factories.uniswapV2, routers.sushiswapV2, tokens.WETH, tokens.DAI, swapAmount, 0).send({
      from: addresses[0],
    });
  } catch (error) {
    console.error(error);
  }
*/
  /*
  await contract.methods.includeCanPayOut(addresses[0], true).send({
    from: addresses[0],
  });
*/
  /* This creates and event emitter linked to eth_subscribe */
  const subscription = web3.eth.subscribe('newBlockHeaders');



  /* This exposes the events from the subscription, synchronously */
  subscription.on('data', async (block, error) => {
    logger.debug('============================================');
    // current block number
    logger.debug(`New block: ${block.number}`);

    // average gas price
    const gasPrice = await web3.eth.getGasPrice();
    logger.debug(`Gas price: ${Math.floor(web3.utils.fromWei(gasPrice, 'gwei'))}`);

    // initialise uniswap v2 calculator
    const uniswapV2EthCalc = new EthereumCalculator(ABIs.uniswapV2Router, routers.uniswapV2, tokens[swapFrom], tokens[swapTo], swapAmount);
    const uniswapV2SellPrice = await uniswapV2EthCalc.getSellPrice();
    const uniswapV2V2BuyPrice = await uniswapV2EthCalc.getBuyPrice();
    const uniswapV2BuyPriceClass = new DexPriceAddress(uniswapV2EthCalc.routerAddress, factories.uniswapV2, uniswapV2V2BuyPrice);
    const uniswapV2SellPriceClass = new DexPriceAddress(uniswapV2EthCalc.routerAddress, factories.uniswapV2, uniswapV2SellPrice);

    // initialise sushiswap v2 calculator
    const sushiswapV2EthCalc = new EthereumCalculator(ABIs.sushiswapV2Router, routers.sushiswapV2, tokens[swapFrom], tokens[swapTo], swapAmount);
    const sushiswapV2SellPrice = await sushiswapV2EthCalc.getSellPrice();
    const sushiswapV2BuyPrice = await sushiswapV2EthCalc.getBuyPrice();
    const sushiswapV2BuyPriceClass = new DexPriceAddress(sushiswapV2EthCalc.routerAddress, factories.sushiswapV2, sushiswapV2BuyPrice);
    const sushiswapV2SellPriceClass = new DexPriceAddress(sushiswapV2EthCalc.routerAddress, factories.sushiswapV2, sushiswapV2SellPrice);

    // initialise bakeryswap v2 calculator
    const bakeryswapV2EthCalc = new EthereumCalculator(ABIs.uniswapV2Router, routers.bakeryswap, tokens[swapFrom], tokens[swapTo], swapAmount);
    const bakerywapV2SellPrice = await bakeryswapV2EthCalc.getSellPrice();
    const bakeryswapV2BuyPrice = await bakeryswapV2EthCalc.getBuyPrice();
    const bakeryswapV2BuyPriceClass = new DexPriceAddress(bakeryswapV2EthCalc.routerAddress, factories.bakeryswap, bakeryswapV2BuyPrice);
    const bakeryswapV2SellPriceClass = new DexPriceAddress(bakeryswapV2EthCalc.routerAddress, factories.bakeryswap, bakerywapV2SellPrice);
    
    const apeswapV2EthCalc = new EthereumCalculator(ABIs.uniswapV2Router, routers.apeswap, tokens[swapFrom], tokens[swapTo], swapAmount);
    const apewapV2SellPrice = await apeswapV2EthCalc.getSellPrice();
    const apeswapV2BuyPrice = await apeswapV2EthCalc.getBuyPrice();
    const apewapV2BuyPriceClass = new DexPriceAddress(apeswapV2EthCalc.routerAddress, factories.apeswap, apeswapV2BuyPrice);
    const apewapV2SellPriceClass = new DexPriceAddress(apeswapV2EthCalc.routerAddress, factories.apeswap, apewapV2SellPrice);
   
    var BuyPriceClasses = [sushiswapV2BuyPriceClass, uniswapV2BuyPriceClass, apewapV2BuyPriceClass];
    var SellPriceClasses = [sushiswapV2SellPriceClass, uniswapV2SellPriceClass, apewapV2SellPriceClass, bakeryswapV2SellPriceClass];
    //0 Index von Buy ist billigste
    BuyPriceClasses = BuyPriceClasses.sort(function (a, b) {  return a.price - b.price;  });
    //0index von Sell ist teuerste
    SellPriceClasses = SellPriceClasses.sort(function (a, b) {  return b.price - a.price;  });

    logger.info(`UniswapV2   | 🟥 Sell | ${swapAmountOhneWei} ${swapFrom} -> ${uniswapV2SellPrice} ${swapTo}`);
    logger.info(`UniswapV2   | 🟩 Buy  | ${swapAmountOhneWei} -> ${uniswapV2V2BuyPrice} ${swapTo}`);
    logger.info(`SushiswapV2 | 🟥 Sell | ${swapAmountOhneWei} -> ${sushiswapV2SellPrice} ${swapTo}`);
    logger.info(`SushiswapV2 | 🟩 Buy  | ${swapAmountOhneWei} -> ${sushiswapV2BuyPrice} ${swapTo}`);
    logger.info(`BakerySwap | 🟥 Sell | ${swapAmountOhneWei} -> ${bakerywapV2SellPrice} ${swapTo}`);
    logger.info(`BakerySwap | 🟩 Buy  | ${swapAmountOhneWei} -> ${bakeryswapV2BuyPrice} ${swapTo}`);
    logger.info(`ApeSwap | 🟥 Sell | ${swapAmountOhneWei} -> ${apewapV2SellPrice} ${swapTo}`);
    logger.info(`ApeSwap | 🟩 Buy  | ${swapAmountOhneWei} -> ${apeswapV2BuyPrice} ${swapTo}`);


    if (BuyPriceClasses[0].price < SellPriceClasses[0].price) {

      try {
        await contract.methods.startArbitrage(BuyPriceClasses[0].factoryAddress, BuyPriceClasses[0].routerAddress, tokens.WETH, tokens.DAI, swapAmount, 0).send({
          from: addresses[0],
        });
      } catch (error) {
        console.error(error);
      }

      const jsonnameFlash = "flashloan.json";
      writeJson.writeJson(jsonnameFlash, block, swapAmountOhneWei, uniswapV2V2BuyPrice, sushiswapV2BuyPrice, bakeryswapV2BuyPrice, apeswapV2BuyPrice, sushiswapV2SellPrice, uniswapV2SellPrice, bakerywapV2SellPrice, apewapV2SellPrice);
      // Hier Contract start Flashloan Function aufrufen
    }
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    // current hours
    let hours = date_ob.getHours();

     // current minutes
   let minutes = date_ob.getMinutes();

    // current seconds
    //let seconds = date_ob.getSeconds();
    console.log(year + "-" + month + "-" + date + ":" + hours);

    var twentyMinutes = 0;

    if (minutes % 20 == 0) {
      twentyMinutes = minutes;
    }

    const jsonname = year + "-" + month + "-" + date + ":" + hours + ":" + twentyMinutes + ".json";
    writeJson.writeJson(jsonname, block, swapAmountOhneWei, uniswapV2V2BuyPrice, sushiswapV2BuyPrice, bakeryswapV2BuyPrice, apeswapV2BuyPrice, sushiswapV2SellPrice, uniswapV2SellPrice, bakerywapV2SellPrice, apewapV2SellPrice);
  });
};




main();
